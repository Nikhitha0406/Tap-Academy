import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { dashboardAPI, attendanceAPI } from '../../services/api';
import { format } from 'date-fns';

const EmployeeDashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [todayStatus, setTodayStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [dashboardRes, todayRes] = await Promise.all([
        dashboardAPI.getEmployeeDashboard(),
        attendanceAPI.getToday(),
      ]);
      setDashboardData(dashboardRes.data.data);
      setTodayStatus(todayRes.data.data);
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCheckIn = async () => {
    setChecking(true);
    try {
      await attendanceAPI.checkIn();
      await loadData();
    } catch (error) {
      alert(error.response?.data?.message || 'Check-in failed');
    } finally {
      setChecking(false);
    }
  };

  const handleCheckOut = async () => {
    setChecking(true);
    try {
      await attendanceAPI.checkOut();
      await loadData();
    } catch (error) {
      alert(error.response?.data?.message || 'Check-out failed');
    } finally {
      setChecking(false);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="text-center py-12">Loading...</div>
      </Layout>
    );
  }

  const statusColors = {
    present: 'bg-green-100 text-green-800',
    absent: 'bg-red-100 text-red-800',
    late: 'bg-yellow-100 text-yellow-800',
    'half-day': 'bg-orange-100 text-orange-800',
  };

  return (
    <Layout>
      <div className="px-4 py-6 sm:px-0">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Dashboard</h1>

        {/* Today's Status Card */}
        <div className="bg-white shadow rounded-lg p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Today's Status</h2>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Date: {todayStatus?.date}</p>
              <span
                className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium mt-2 ${
                  statusColors[todayStatus?.status] || statusColors.absent
                }`}
              >
                {todayStatus?.status?.toUpperCase() || 'ABSENT'}
              </span>
              {todayStatus?.checkInTime && (
                <p className="text-sm text-gray-600 mt-2">
                  Check In: {format(new Date(todayStatus.checkInTime), 'HH:mm')}
                </p>
              )}
              {todayStatus?.checkOutTime && (
                <p className="text-sm text-gray-600">
                  Check Out: {format(new Date(todayStatus.checkOutTime), 'HH:mm')}
                </p>
              )}
            </div>
            <div className="flex gap-4">
              {!todayStatus?.checkInTime && (
                <button
                  onClick={handleCheckIn}
                  disabled={checking}
                  className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 disabled:opacity-50"
                >
                  {checking ? 'Processing...' : 'Check In'}
                </button>
              )}
              {todayStatus?.checkInTime && !todayStatus?.checkOutTime && (
                <button
                  onClick={handleCheckOut}
                  disabled={checking}
                  className="bg-red-600 text-white px-6 py-2 rounded-md hover:bg-red-700 disabled:opacity-50"
                >
                  {checking ? 'Processing...' : 'Check Out'}
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        {dashboardData && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-white shadow rounded-lg p-6">
              <h3 className="text-sm font-medium text-gray-500">Present This Month</h3>
              <p className="text-3xl font-bold text-gray-900 mt-2">
                {dashboardData.thisMonth.present}
              </p>
            </div>
            <div className="bg-white shadow rounded-lg p-6">
              <h3 className="text-sm font-medium text-gray-500">Absent This Month</h3>
              <p className="text-3xl font-bold text-gray-900 mt-2">
                {dashboardData.thisMonth.absent}
              </p>
            </div>
            <div className="bg-white shadow rounded-lg p-6">
              <h3 className="text-sm font-medium text-gray-500">Total Hours This Month</h3>
              <p className="text-3xl font-bold text-gray-900 mt-2">
                {dashboardData.totalHoursThisMonth.toFixed(1)}h
              </p>
            </div>
          </div>
        )}

        {/* Recent 7 Days */}
        {dashboardData && (
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Recent 7 Days</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Check In
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Check Out
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Hours
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {dashboardData.recent.map((day) => (
                    <tr key={day.date}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {format(new Date(day.date), 'MMM dd, yyyy')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            statusColors[day.status] || statusColors.absent
                          }`}
                        >
                          {day.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {day.checkInTime
                          ? format(new Date(day.checkInTime), 'HH:mm')
                          : '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {day.checkOutTime
                          ? format(new Date(day.checkOutTime), 'HH:mm')
                          : '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {day.totalHours ? `${day.totalHours.toFixed(1)}h` : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default EmployeeDashboard;

