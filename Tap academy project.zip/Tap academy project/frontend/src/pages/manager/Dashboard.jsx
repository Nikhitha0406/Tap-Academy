import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { dashboardAPI, attendanceAPI } from '../../services/api';
import { format } from 'date-fns';

const ManagerDashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [todayStatus, setTodayStatus] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [dashboardRes, todayRes] = await Promise.all([
        dashboardAPI.getManagerDashboard(),
        attendanceAPI.getTodayStatus(),
      ]);
      setDashboardData(dashboardRes.data.data);
      setTodayStatus(todayRes.data.data);
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="text-center py-12">Loading...</div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="px-4 py-6 sm:px-0">
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Manager Dashboard</h1>

        {/* Stats Cards */}
        {dashboardData && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <div className="bg-white shadow rounded-lg p-6">
              <h3 className="text-sm font-medium text-gray-500">Total Employees</h3>
              <p className="text-3xl font-bold text-gray-900 mt-2">
                {dashboardData.totalEmployees}
              </p>
            </div>
            <div className="bg-white shadow rounded-lg p-6">
              <h3 className="text-sm font-medium text-gray-500">Present Today</h3>
              <p className="text-3xl font-bold text-green-600 mt-2">
                {dashboardData.todaysPresent}
              </p>
            </div>
            <div className="bg-white shadow rounded-lg p-6">
              <h3 className="text-sm font-medium text-gray-500">Absent Today</h3>
              <p className="text-3xl font-bold text-red-600 mt-2">
                {dashboardData.todaysAbsent}
              </p>
            </div>
            <div className="bg-white shadow rounded-lg p-6">
              <h3 className="text-sm font-medium text-gray-500">Late Today</h3>
              <p className="text-3xl font-bold text-yellow-600 mt-2">
                {dashboardData.lateToday}
              </p>
            </div>
          </div>
        )}

        {/* Today's Status */}
        {todayStatus && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-white shadow rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-4 text-green-600">Present</h2>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {todayStatus.present.length === 0 ? (
                  <p className="text-sm text-gray-500">No employees present</p>
                ) : (
                  todayStatus.present.map((emp) => (
                    <div key={emp.employeeId} className="text-sm">
                      <p className="font-medium">{emp.name}</p>
                      <p className="text-gray-500">{emp.employeeId} - {emp.department}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
            <div className="bg-white shadow rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-4 text-red-600">Absent</h2>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {todayStatus.absent.length === 0 ? (
                  <p className="text-sm text-gray-500">No employees absent</p>
                ) : (
                  todayStatus.absent.map((emp) => (
                    <div key={emp.employeeId} className="text-sm">
                      <p className="font-medium">{emp.name}</p>
                      <p className="text-gray-500">{emp.employeeId} - {emp.department}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
            <div className="bg-white shadow rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-4 text-yellow-600">Late</h2>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {todayStatus.late.length === 0 ? (
                  <p className="text-sm text-gray-500">No employees late</p>
                ) : (
                  todayStatus.late.map((emp) => (
                    <div key={emp.employeeId} className="text-sm">
                      <p className="font-medium">{emp.name}</p>
                      <p className="text-gray-500">{emp.employeeId} - {emp.department}</p>
                      {emp.checkInTime && (
                        <p className="text-xs text-gray-400">
                          Checked in: {format(new Date(emp.checkInTime), 'HH:mm')}
                        </p>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* Weekly Trend */}
        {dashboardData && (
          <div className="bg-white shadow rounded-lg p-6 mb-6">
            <h2 className="text-xl font-semibold mb-4">Weekly Trend</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Present
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Total
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Percentage
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {dashboardData.weeklyTrend.map((day) => (
                    <tr key={day.date}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {format(new Date(day.date), 'MMM dd, yyyy')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {day.present}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {day.total}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {((day.present / day.total) * 100).toFixed(1)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Department Breakdown */}
        {dashboardData && (
          <div className="bg-white shadow rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Department Breakdown</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Department
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Total
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Present
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Late
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                      Absent
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {dashboardData.deptBreakdown.map((dept) => (
                    <tr key={dept.department}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {dept.department}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {dept.total}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600">
                        {dept.present}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-yellow-600">
                        {dept.late}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-red-600">
                        {dept.absent}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default ManagerDashboard;

