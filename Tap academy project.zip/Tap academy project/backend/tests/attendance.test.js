import request from 'supertest';
import mongoose from 'mongoose';
import app from '../src/server.js';
import User from '../src/models/User.model.js';
import Attendance from '../src/models/Attendance.model.js';
import { generateToken } from '../src/utils/jwt.utils.js';
import dotenv from 'dotenv';

dotenv.config();

describe('Attendance API', () => {
  let employeeToken;
  let employeeId;
  let managerToken;

  beforeAll(async () => {
    await mongoose.connect(process.env.DB_URL || 'mongodb://localhost:27017/test_attendance');
  });

  afterAll(async () => {
    await mongoose.connection.close();
  });

  beforeEach(async () => {
    await User.deleteMany({});
    await Attendance.deleteMany({});

    // Create employee
    const employee = await User.create({
      name: 'Test Employee',
      email: 'employee@test.com',
      password: 'Password123!',
      employeeId: 'EMP001',
      department: 'Engineering',
      role: 'employee',
    });
    employeeId = employee._id;
    employeeToken = generateToken(employee._id);

    // Create manager
    const manager = await User.create({
      name: 'Test Manager',
      email: 'manager@test.com',
      password: 'Password123!',
      employeeId: 'MGR001',
      department: 'HR',
      role: 'manager',
    });
    managerToken = generateToken(manager._id);
  });

  describe('POST /api/attendance/checkin', () => {
    it('should check in successfully', async () => {
      const response = await request(app)
        .post('/api/attendance/checkin')
        .set('Authorization', `Bearer ${employeeToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('checkInTime');
      expect(response.body.data).toHaveProperty('status');
    });

    it('should not check in twice on same day', async () => {
      await request(app)
        .post('/api/attendance/checkin')
        .set('Authorization', `Bearer ${employeeToken}`)
        .expect(200);

      const response = await request(app)
        .post('/api/attendance/checkin')
        .set('Authorization', `Bearer ${employeeToken}`)
        .expect(400);

      expect(response.body.success).toBe(false);
    });
  });

  describe('POST /api/attendance/checkout', () => {
    it('should check out successfully after check in', async () => {
      // First check in
      await request(app)
        .post('/api/attendance/checkin')
        .set('Authorization', `Bearer ${employeeToken}`)
        .expect(200);

      // Then check out
      const response = await request(app)
        .post('/api/attendance/checkout')
        .set('Authorization', `Bearer ${employeeToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toHaveProperty('checkOutTime');
      expect(response.body.data).toHaveProperty('totalHours');
    });

    it('should not check out without check in', async () => {
      const response = await request(app)
        .post('/api/attendance/checkout')
        .set('Authorization', `Bearer ${employeeToken}`)
        .expect(400);

      expect(response.body.success).toBe(false);
    });
  });

  describe('GET /api/attendance/my-history', () => {
    it('should get attendance history', async () => {
      // Create some attendance records
      const today = new Date().toISOString().split('T')[0];
      await Attendance.create({
        userId: employeeId,
        date: today,
        checkInTime: new Date(),
        status: 'present',
      });

      const response = await request(app)
        .get('/api/attendance/my-history')
        .set('Authorization', `Bearer ${employeeToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toBeInstanceOf(Array);
    });
  });

  describe('GET /api/attendance/all (Manager)', () => {
    it('should get all attendance for manager', async () => {
      const response = await request(app)
        .get('/api/attendance/all')
        .set('Authorization', `Bearer ${managerToken}`)
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data).toBeInstanceOf(Array);
    });

    it('should not allow employee to access', async () => {
      const response = await request(app)
        .get('/api/attendance/all')
        .set('Authorization', `Bearer ${employeeToken}`)
        .expect(403);

      expect(response.body.success).toBe(false);
    });
  });
});

