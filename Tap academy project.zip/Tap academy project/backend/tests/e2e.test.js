import axios from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const API_URL = process.env.API_URL || 'http://localhost:5000/api';

/**
 * E2E Test Script
 * Simulates: Login -> Check In -> Check Out
 */
async function e2eTest() {
  try {
    console.log('Starting E2E Test...\n');

    // Step 1: Login
    console.log('1. Logging in...');
    const loginResponse = await axios.post(`${API_URL}/auth/login`, {
      email: 'employee1@example.com',
      password: 'Password123!',
    });

    if (!loginResponse.data.success) {
      throw new Error('Login failed');
    }

    const token = loginResponse.data.data.token;
    const user = loginResponse.data.data.user;
    console.log(`✓ Logged in as ${user.name} (${user.employeeId})\n`);

    // Step 2: Check In
    console.log('2. Checking in...');
    const checkInResponse = await axios.post(
      `${API_URL}/attendance/checkin`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (!checkInResponse.data.success) {
      throw new Error('Check-in failed');
    }

    const attendance = checkInResponse.data.data;
    console.log(`✓ Checked in at ${new Date(attendance.checkInTime).toLocaleTimeString()}`);
    console.log(`  Status: ${attendance.status}\n`);

    // Step 3: Get Today's Status
    console.log('3. Getting today\'s status...');
    const todayResponse = await axios.get(`${API_URL}/attendance/today`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (todayResponse.data.success) {
      const today = todayResponse.data.data;
      console.log(`✓ Today's status: ${today.status}`);
      if (today.checkInTime) {
        console.log(`  Check In: ${new Date(today.checkInTime).toLocaleTimeString()}`);
      }
    }

    // Step 4: Check Out (after a short delay to simulate work)
    console.log('\n4. Waiting 2 seconds before checkout...');
    await new Promise((resolve) => setTimeout(resolve, 2000));

    console.log('5. Checking out...');
    const checkOutResponse = await axios.post(
      `${API_URL}/attendance/checkout`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (!checkOutResponse.data.success) {
      throw new Error('Check-out failed');
    }

    const finalAttendance = checkOutResponse.data.data;
    console.log(`✓ Checked out at ${new Date(finalAttendance.checkOutTime).toLocaleTimeString()}`);
    console.log(`  Total Hours: ${finalAttendance.totalHours?.toFixed(2) || 0} hours`);
    console.log(`  Final Status: ${finalAttendance.status}\n`);

    console.log('✅ E2E Test completed successfully!');
  } catch (error) {
    console.error('❌ E2E Test failed:', error.response?.data?.message || error.message);
    process.exit(1);
  }
}

// Run the test
e2eTest();

