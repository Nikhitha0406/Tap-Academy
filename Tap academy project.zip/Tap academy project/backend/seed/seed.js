import mongoose from 'mongoose';
import dotenv from 'dotenv';
import User from '../src/models/User.model.js';
import Attendance from '../src/models/Attendance.model.js';
import { format, subDays, addHours, addMinutes } from 'date-fns';

dotenv.config();

const seedUsers = [
  {
    name: 'Asha Rao',
    email: 'manager@example.com',
    password: 'Password123!',
    role: 'manager',
    employeeId: 'MGR001',
    department: 'HR',
  },
  {
    name: 'Kukati Nikhitha',
    email: 'employee1@example.com',
    password: 'Password123!',
    role: 'employee',
    employeeId: 'EMP001',
    department: 'Engineering',
  },
  {
    name: 'John Doe',
    email: 'employee2@example.com',
    password: 'Password123!',
    role: 'employee',
    employeeId: 'EMP002',
    department: 'Engineering',
  },
  {
    name: 'Jane Smith',
    email: 'employee3@example.com',
    password: 'Password123!',
    role: 'employee',
    employeeId: 'EMP003',
    department: 'Marketing',
  },
  {
    name: 'Bob Johnson',
    email: 'employee4@example.com',
    password: 'Password123!',
    role: 'employee',
    employeeId: 'EMP004',
    department: 'Sales',
  },
  {
    name: 'Alice Williams',
    email: 'employee5@example.com',
    password: 'Password123!',
    role: 'employee',
    employeeId: 'EMP005',
    department: 'Finance',
  },
];

const generateAttendance = (userId, date, status) => {
  const baseDate = new Date(date);
  let checkInTime = null;
  let checkOutTime = null;
  let totalHours = null;

  if (status === 'present' || status === 'late' || status === 'half-day') {
    // Check in between 8:30 AM and 9:30 AM (late if after 9:15)
    const checkInHour = status === 'late' ? 9 : 8;
    const checkInMinute = status === 'late' ? 20 : 45;
    checkInTime = addHours(
      addMinutes(baseDate, checkInMinute),
      checkInHour
    );

    // Check out between 5:00 PM and 6:00 PM
    const checkOutHour = status === 'half-day' ? 12 : 17;
    const checkOutMinute = status === 'half-day' ? 30 : Math.floor(Math.random() * 60);
    checkOutTime = addHours(
      addMinutes(baseDate, checkOutMinute),
      checkOutHour
    );

    totalHours = (checkOutTime - checkInTime) / (1000 * 60 * 60);
    totalHours = Math.round(totalHours * 100) / 100;
  }

  return {
    userId,
    date: format(baseDate, 'yyyy-MM-dd'),
    checkInTime,
    checkOutTime,
    status,
    totalHours,
  };
};

const seed = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.DB_URL);
    console.log('Connected to MongoDB');

    // Clear existing data
    await User.deleteMany({});
    await Attendance.deleteMany({});
    console.log('Cleared existing data');

    // Create users
    const createdUsers = [];
    for (const userData of seedUsers) {
      const user = await User.create(userData);
      createdUsers.push(user);
      console.log(`Created user: ${user.name} (${user.employeeId})`);
    }

    // Get employees only (excluding manager)
    const employees = createdUsers.filter((u) => u.role === 'employee');

    // Generate attendance for last 30 days
    const today = new Date();
    const attendanceRecords = [];

    for (let i = 0; i < 30; i++) {
      const date = subDays(today, i);
      const dayOfWeek = date.getDay(); // 0 = Sunday, 6 = Saturday

      // Skip weekends (Saturday = 6, Sunday = 0)
      if (dayOfWeek === 0 || dayOfWeek === 6) {
        continue;
      }

      for (const employee of employees) {
        // Random status distribution
        const rand = Math.random();
        let status;

        if (rand < 0.7) {
          // 70% present
          status = Math.random() < 0.2 ? 'late' : 'present';
        } else if (rand < 0.85) {
          // 15% absent
          status = 'absent';
        } else {
          // 15% half-day
          status = 'half-day';
        }

        const attendance = generateAttendance(employee._id, date, status);
        attendanceRecords.push(attendance);
      }
    }

    // Insert attendance records
    await Attendance.insertMany(attendanceRecords);
    console.log(`Created ${attendanceRecords.length} attendance records`);

    console.log('Seed completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
};

seed();

