import Attendance from '../models/Attendance.model.js';
import User from '../models/User.model.js';
import {
  getTodayDate,
  isLate,
  calculateHours,
  getStatus,
} from '../utils/date.utils.js';

// Employee: Check In
export const checkIn = async (req, res) => {
  try {
    const userId = req.user._id;
    const today = getTodayDate();

    // Check if already checked in today
    const existingAttendance = await Attendance.findOne({
      userId,
      date: today,
    });

    if (existingAttendance && existingAttendance.checkInTime) {
      return res.status(400).json({
        success: false,
        message: 'Already checked in today',
      });
    }

    const checkInTime = new Date();
    const deadline = process.env.CHECKIN_DEADLINE || '09:15';
    const status = isLate(checkInTime, deadline) ? 'late' : 'present';

    let attendance;
    if (existingAttendance) {
      // Update existing record
      attendance = await Attendance.findByIdAndUpdate(
        existingAttendance._id,
        {
          checkInTime,
          status,
        },
        { new: true }
      );
    } else {
      // Create new record
      attendance = await Attendance.create({
        userId,
        date: today,
        checkInTime,
        status,
      });
    }

    await attendance.populate('userId', 'name email employeeId department');

    res.json({
      success: true,
      message: 'Checked in successfully',
      data: attendance,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Error checking in',
    });
  }
};

// Employee: Check Out
export const checkOut = async (req, res) => {
  try {
    const userId = req.user._id;
    const today = getTodayDate();

    const attendance = await Attendance.findOne({
      userId,
      date: today,
    });

    if (!attendance || !attendance.checkInTime) {
      return res.status(400).json({
        success: false,
        message: 'Please check in first',
      });
    }

    if (attendance.checkOutTime) {
      return res.status(400).json({
        success: false,
        message: 'Already checked out today',
      });
    }

    const checkOutTime = new Date();
    const totalHours = calculateHours(attendance.checkInTime, checkOutTime);
    const deadline = process.env.CHECKIN_DEADLINE || '09:15';
    const status = getStatus(
      attendance.checkInTime,
      checkOutTime,
      totalHours,
      deadline
    );

    attendance.checkOutTime = checkOutTime;
    attendance.totalHours = totalHours;
    attendance.status = status;
    await attendance.save();

    await attendance.populate('userId', 'name email employeeId department');

    res.json({
      success: true,
      message: 'Checked out successfully',
      data: attendance,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Error checking out',
    });
  }
};

// Employee: Get today's attendance
export const getToday = async (req, res) => {
  try {
    const userId = req.user._id;
    const today = getTodayDate();

    const attendance = await Attendance.findOne({
      userId,
      date: today,
    });

    if (!attendance) {
      return res.json({
        success: true,
        data: {
          date: today,
          status: 'absent',
          checkInTime: null,
          checkOutTime: null,
        },
      });
    }

    res.json({
      success: true,
      data: {
        date: attendance.date,
        status: attendance.status,
        checkInTime: attendance.checkInTime,
        checkOutTime: attendance.checkOutTime,
        totalHours: attendance.totalHours,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Error fetching today attendance',
    });
  }
};

// Employee: Get my attendance history
export const getMyHistory = async (req, res) => {
  try {
    const userId = req.user._id;
    const { from, to, page = 1, limit = 30 } = req.query;

    const query = { userId };

    if (from || to) {
      query.date = {};
      if (from) query.date.$gte = from;
      if (to) query.date.$lte = to;
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [data, total] = await Promise.all([
      Attendance.find(query)
        .sort({ date: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .populate('userId', 'name email employeeId department'),
      Attendance.countDocuments(query),
    ]);

    res.json({
      success: true,
      data,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Error fetching attendance history',
    });
  }
};

// Employee: Get monthly summary
export const getMySummary = async (req, res) => {
  try {
    const userId = req.user._id;
    const { month } = req.query; // YYYY-MM format

    if (!month) {
      return res.status(400).json({
        success: false,
        message: 'Please provide month in YYYY-MM format',
      });
    }

    const startDate = `${month}-01`;
    const endDate = `${month}-31`;

    const attendances = await Attendance.find({
      userId,
      date: { $gte: startDate, $lte: endDate },
    });

    const present = attendances.filter((a) => a.status === 'present').length;
    const absent = attendances.filter((a) => a.status === 'absent').length;
    const late = attendances.filter((a) => a.status === 'late').length;
    const halfDay = attendances.filter((a) => a.status === 'half-day').length;
    const totalHours = attendances.reduce(
      (sum, a) => sum + (a.totalHours || 0),
      0
    );

    res.json({
      success: true,
      data: {
        present,
        absent,
        late,
        halfDay,
        totalHours: Math.round(totalHours * 100) / 100,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Error fetching summary',
    });
  }
};

// Manager: Get all attendance with filters
export const getAllAttendance = async (req, res) => {
  try {
    const {
      employeeId,
      from,
      to,
      status,
      department,
      page = 1,
      limit = 50,
    } = req.query;

    const query = {};

    if (from || to) {
      query.date = {};
      if (from) query.date.$gte = from;
      if (to) query.date.$lte = to;
    }

    if (status) {
      query.status = status;
    }

    // Build user query for employeeId and department
    const userQuery = {};
    if (employeeId) {
      userQuery.employeeId = employeeId;
    }
    if (department) {
      userQuery.department = department;
    }

    let userIds = [];
    if (Object.keys(userQuery).length > 0) {
      const users = await User.find(userQuery).select('_id');
      userIds = users.map((u) => u._id);
      if (userIds.length === 0) {
        return res.json({
          success: true,
          data: [],
          total: 0,
          page: parseInt(page),
          limit: parseInt(limit),
        });
      }
      query.userId = { $in: userIds };
    }

    const skip = (parseInt(page) - 1) * parseInt(limit);

    const [data, total] = await Promise.all([
      Attendance.find(query)
        .sort({ date: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .populate('userId', 'name email employeeId department'),
      Attendance.countDocuments(query),
    ]);

    res.json({
      success: true,
      data,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Error fetching attendance',
    });
  }
};

// Manager: Get employee attendance
export const getEmployeeAttendance = async (req, res) => {
  try {
    const { id } = req.params;
    const { from, to } = req.query;

    const user = await User.findById(id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found',
      });
    }

    const query = { userId: id };
    if (from || to) {
      query.date = {};
      if (from) query.date.$gte = from;
      if (to) query.date.$lte = to;
    }

    const data = await Attendance.find(query)
      .sort({ date: -1 })
      .populate('userId', 'name email employeeId department');

    res.json({
      success: true,
      data,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Error fetching employee attendance',
    });
  }
};

// Manager: Get attendance summary
export const getSummary = async (req, res) => {
  try {
    const { from, to, department } = req.query;

    const userQuery = {};
    if (department) {
      userQuery.department = department;
    }

    const users = await User.find(userQuery);
    const userIds = users.map((u) => u._id);

    const attendanceQuery = { userId: { $in: userIds } };
    if (from || to) {
      attendanceQuery.date = {};
      if (from) attendanceQuery.date.$gte = from;
      if (to) attendanceQuery.date.$lte = to;
    }

    const attendances = await Attendance.find(attendanceQuery).populate(
      'userId',
      'name employeeId department'
    );

    // Calculate totals by employee
    const totalsByEmployee = {};
    users.forEach((user) => {
      totalsByEmployee[user.employeeId] = {
        name: user.name,
        employeeId: user.employeeId,
        department: user.department,
        present: 0,
        absent: 0,
        late: 0,
        halfDay: 0,
        totalHours: 0,
      };
    });

    attendances.forEach((att) => {
      const empId = att.userId.employeeId;
      if (totalsByEmployee[empId]) {
        totalsByEmployee[empId][att.status]++;
        totalsByEmployee[empId].totalHours += att.totalHours || 0;
      }
    });

    // Calculate totals by department
    const totalsByDepartment = {};
    attendances.forEach((att) => {
      const dept = att.userId.department;
      if (!totalsByDepartment[dept]) {
        totalsByDepartment[dept] = {
          department: dept,
          present: 0,
          absent: 0,
          late: 0,
          halfDay: 0,
          totalHours: 0,
        };
      }
      totalsByDepartment[dept][att.status]++;
      totalsByDepartment[dept].totalHours += att.totalHours || 0;
    });

    // Overall counts
    const presentCount = attendances.filter((a) => a.status === 'present').length;
    const absentCount = attendances.filter((a) => a.status === 'absent').length;
    const lateCount = attendances.filter((a) => a.status === 'late').length;

    res.json({
      success: true,
      data: {
        totalsByEmployee: Object.values(totalsByEmployee),
        totalsByDepartment: Object.values(totalsByDepartment),
        presentCount,
        absentCount,
        lateCount,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Error fetching summary',
    });
  }
};

// Manager: Export CSV
export const exportCSV = async (req, res) => {
  try {
    const { from, to, employeeId, department } = req.query;

    const query = {};

    if (from || to) {
      query.date = {};
      if (from) query.date.$gte = from;
      if (to) query.date.$lte = to;
    }

    const userQuery = {};
    if (employeeId) {
      userQuery.employeeId = employeeId;
    }
    if (department) {
      userQuery.department = department;
    }

    let userIds = [];
    if (Object.keys(userQuery).length > 0) {
      const users = await User.find(userQuery).select('_id');
      userIds = users.map((u) => u._id);
      if (userIds.length === 0) {
        return res.status(404).json({
          success: false,
          message: 'No records found',
        });
      }
      query.userId = { $in: userIds };
    }

    const attendances = await Attendance.find(query)
      .sort({ date: -1 })
      .populate('userId', 'name email employeeId department');

    if (attendances.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No records found',
      });
    }

    // Generate CSV
    const { format } = await import('fast-csv');
    const csvStream = format({ headers: true });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename=attendance-${from || 'all'}-${to || 'all'}.csv`
    );

    csvStream.pipe(res);

    // Write headers
    csvStream.write({
      employeeId: 'Employee ID',
      name: 'Name',
      date: 'Date',
      checkInTime: 'Check In Time',
      checkOutTime: 'Check Out Time',
      totalHours: 'Total Hours',
      status: 'Status',
      department: 'Department',
    });

    // Write data
    attendances.forEach((att) => {
      csvStream.write({
        employeeId: att.userId.employeeId,
        name: att.userId.name,
        date: att.date,
        checkInTime: att.checkInTime
          ? new Date(att.checkInTime).toISOString()
          : '',
        checkOutTime: att.checkOutTime
          ? new Date(att.checkOutTime).toISOString()
          : '',
        totalHours: att.totalHours || 0,
        status: att.status,
        department: att.userId.department,
      });
    });

    csvStream.end();
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Error exporting CSV',
    });
  }
};

// Manager: Get today's status
export const getTodayStatus = async (req, res) => {
  try {
    const today = getTodayDate();
    const deadline = process.env.CHECKIN_DEADLINE || '09:15';

    const attendances = await Attendance.find({ date: today }).populate(
      'userId',
      'name email employeeId department'
    );

    const present = [];
    const absent = [];
    const late = [];

    const allUsers = await User.find({ role: 'employee' });

    // Check each user
    allUsers.forEach((user) => {
      const att = attendances.find(
        (a) => a.userId._id.toString() === user._id.toString()
      );

      if (!att || !att.checkInTime) {
        absent.push({
          employeeId: user.employeeId,
          name: user.name,
          department: user.department,
        });
      } else if (isLate(att.checkInTime, deadline)) {
        late.push({
          employeeId: user.employeeId,
          name: user.name,
          department: user.department,
          checkInTime: att.checkInTime,
        });
      } else {
        present.push({
          employeeId: user.employeeId,
          name: user.name,
          department: user.department,
          checkInTime: att.checkInTime,
          checkOutTime: att.checkOutTime,
        });
      }
    });

    res.json({
      success: true,
      data: {
        present,
        absent,
        late,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Error fetching today status',
    });
  }
};

