import Attendance from '../models/Attendance.model.js';
import User from '../models/User.model.js';
import { getTodayDate, format, subDays, startOfMonth, endOfMonth } from 'date-fns';
import { isLate } from '../utils/date.utils.js';

// Employee Dashboard
export const getEmployeeDashboard = async (req, res) => {
  try {
    const userId = req.user._id;
    const today = getTodayDate();
    const currentMonth = format(new Date(), 'yyyy-MM');

    // Today's status
    const todayAttendance = await Attendance.findOne({
      userId,
      date: today,
    });

    const todayStatus = {
      date: today,
      status: todayAttendance?.status || 'absent',
      checkInTime: todayAttendance?.checkInTime || null,
      checkOutTime: todayAttendance?.checkOutTime || null,
      totalHours: todayAttendance?.totalHours || null,
    };

    // This month summary
    const startDate = `${currentMonth}-01`;
    const endDate = `${currentMonth}-31`;

    const monthAttendances = await Attendance.find({
      userId,
      date: { $gte: startDate, $lte: endDate },
    });

    const thisMonth = {
      present: monthAttendances.filter((a) => a.status === 'present').length,
      absent: monthAttendances.filter((a) => a.status === 'absent').length,
      late: monthAttendances.filter((a) => a.status === 'late').length,
    };

    const totalHoursThisMonth = monthAttendances.reduce(
      (sum, a) => sum + (a.totalHours || 0),
      0
    );

    // Recent 7 days
    const recentDates = [];
    for (let i = 0; i < 7; i++) {
      const date = subDays(new Date(), i);
      recentDates.push(format(date, 'yyyy-MM-dd'));
    }

    const recentAttendances = await Attendance.find({
      userId,
      date: { $in: recentDates },
    }).sort({ date: -1 });

    const recent = recentDates.map((date) => {
      const att = recentAttendances.find((a) => a.date === date);
      return {
        date,
        status: att?.status || 'absent',
        checkInTime: att?.checkInTime || null,
        checkOutTime: att?.checkOutTime || null,
        totalHours: att?.totalHours || null,
      };
    });

    res.json({
      success: true,
      data: {
        todayStatus,
        thisMonth,
        totalHoursThisMonth: Math.round(totalHoursThisMonth * 100) / 100,
        recent,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Error fetching dashboard data',
    });
  }
};

// Manager Dashboard
export const getManagerDashboard = async (req, res) => {
  try {
    const today = getTodayDate();
    const deadline = process.env.CHECKIN_DEADLINE || '09:15';

    // Total employees
    const totalEmployees = await User.countDocuments({ role: 'employee' });

    // Today's attendance
    const todayAttendances = await Attendance.find({ date: today }).populate(
      'userId',
      'name employeeId department'
    );

    const allUsers = await User.find({ role: 'employee' });
    let todaysPresent = 0;
    let todaysAbsent = 0;
    let lateToday = 0;

    allUsers.forEach((user) => {
      const att = todayAttendances.find(
        (a) => a.userId._id.toString() === user._id.toString()
      );
      if (!att || !att.checkInTime) {
        todaysAbsent++;
      } else if (isLate(att.checkInTime, deadline)) {
        lateToday++;
        todaysPresent++;
      } else {
        todaysPresent++;
      }
    });

    // Weekly trend (last 7 days)
    const weeklyTrend = [];
    for (let i = 6; i >= 0; i--) {
      const date = subDays(new Date(), i);
      const dateStr = format(date, 'yyyy-MM-dd');
      const dayAttendances = await Attendance.find({ date: dateStr });
      const presentCount = dayAttendances.filter(
        (a) => a.status === 'present' || a.status === 'late'
      ).length;
      weeklyTrend.push({
        date: dateStr,
        present: presentCount,
        total: totalEmployees,
      });
    }

    // Department breakdown
    const departments = await User.distinct('department', {
      role: 'employee',
    });

    const deptBreakdown = await Promise.all(
      departments.map(async (dept) => {
        const deptUsers = await User.find({
          department: dept,
          role: 'employee',
        });
        const deptUserIds = deptUsers.map((u) => u._id);
        const deptAttendances = await Attendance.find({
          userId: { $in: deptUserIds },
          date: today,
        });
        const present = deptAttendances.filter(
          (a) => a.checkInTime && !isLate(a.checkInTime, deadline)
        ).length;
        const late = deptAttendances.filter((a) =>
          isLate(a.checkInTime, deadline)
        ).length;
        const absent = deptUsers.length - present - late;

        return {
          department: dept,
          total: deptUsers.length,
          present,
          late,
          absent,
        };
      })
    );

    res.json({
      success: true,
      data: {
        totalEmployees,
        todaysPresent,
        todaysAbsent,
        lateToday,
        weeklyTrend,
        deptBreakdown,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message || 'Error fetching dashboard data',
    });
  }
};

