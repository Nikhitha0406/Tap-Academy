import express from 'express';
import { authenticate, requireManager } from '../middleware/auth.middleware.js';
import {
  checkIn,
  checkOut,
  getToday,
  getMyHistory,
  getMySummary,
  getAllAttendance,
  getEmployeeAttendance,
  getSummary,
  exportCSV,
  getTodayStatus,
} from '../controllers/attendance.controller.js';

const router = express.Router();

// Employee routes
router.post('/checkin', authenticate, checkIn);
router.post('/checkout', authenticate, checkOut);
router.get('/today', authenticate, getToday);
router.get('/my-history', authenticate, getMyHistory);
router.get('/my-summary', authenticate, getMySummary);

// Manager routes
router.get('/all', authenticate, requireManager, getAllAttendance);
router.get('/employee/:id', authenticate, requireManager, getEmployeeAttendance);
router.get('/summary', authenticate, requireManager, getSummary);
router.get('/export', authenticate, requireManager, exportCSV);
router.get('/today-status', authenticate, requireManager, getTodayStatus);

export default router;

