import express from 'express';
import { authenticate, requireManager } from '../middleware/auth.middleware.js';
import {
  getEmployeeDashboard,
  getManagerDashboard,
} from '../controllers/dashboard.controller.js';

const router = express.Router();

router.get('/employee', authenticate, getEmployeeDashboard);
router.get('/manager', authenticate, requireManager, getManagerDashboard);

export default router;

