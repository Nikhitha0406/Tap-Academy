import { format, parse, startOfDay, differenceInHours } from 'date-fns';

export const getTodayDate = () => {
  return format(new Date(), 'yyyy-MM-dd');
};

export const parseTime = (timeString) => {
  const [hours, minutes] = timeString.split(':').map(Number);
  const today = new Date();
  today.setHours(hours, minutes, 0, 0);
  return today;
};

export const isLate = (checkInTime, deadline = '09:15') => {
  const deadlineTime = parseTime(deadline);
  const checkIn = new Date(checkInTime);
  return checkIn > deadlineTime;
};

export const calculateHours = (checkInTime, checkOutTime) => {
  if (!checkInTime || !checkOutTime) return null;
  const hours = differenceInHours(new Date(checkOutTime), new Date(checkInTime));
  return Math.round((hours + Number.EPSILON) * 100) / 100;
};

export const getStatus = (checkInTime, checkOutTime, totalHours, deadline = '09:15') => {
  if (!checkInTime) return 'absent';
  if (isLate(checkInTime, deadline)) return 'late';
  if (totalHours && totalHours < 4) return 'half-day';
  return 'present';
};

